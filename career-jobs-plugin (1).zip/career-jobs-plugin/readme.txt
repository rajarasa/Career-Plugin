Career Jobs Plugin
==================

Install:
1. Upload the zip to WordPress Plugins > Add New > Upload Plugin.
2. Activate.
3. Add jobs via the 'Career Jobs' menu in admin.
4. Place the shortcode [career_jobs] on your Careers page.

Notes:
- Uses featured image, title, and editor content for each job.
- Popup loads details via AJAX.
